package basics;

public class WhileLoop {

	public static void main(String[] args) {
		
		int n = 5;
			while(n>0) {
				System.out.println(" tick " + n);
				// post subtraction operator
				n--;								
			}	
		}
	}
