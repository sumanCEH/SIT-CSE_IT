package basics;

public class Operators {

	public static void main(String[] args) {
		int a = 7, b = 6;
		int c = a * b;  // [*] multiplication operator
		int d = a + b;	// [+] addition operator
		int e = a / b;	// [-] subtraction operator
		int f = a % b;	// [%] modulus operator
		int g = a ^ b;	// [^] power operator
		long h = b ^ a;	// [^] power operator
		System.out.println(c + " " + d + " " + e + " " + f + " " + g + " " + h); // here  + is to add two strings
	}

}
