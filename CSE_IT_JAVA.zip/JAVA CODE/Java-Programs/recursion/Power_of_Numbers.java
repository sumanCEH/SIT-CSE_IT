package recursion;

public class Power_of_Numbers {
    public static void main(String[] args) {

    }
}