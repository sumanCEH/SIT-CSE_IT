package trees.binaryTree;
/*	Problem Title :- Write a Java program to find Left View of a tree
 * 
 *  Left View of a tree :- 
 *  The left view of a binary tree, is set of nodes visible when tree is visited from left side
 *  between two end nodes.
 */

public class BT_Problem_07 {

	public static void main(String[] args) {
		
	}

}
