package dp;

public class Optimal_Binary_Search {

//  static int optimalBinarySearch(int[] keys, int[] freq, int n) {}

  public static void main(String[] args) {}
}
