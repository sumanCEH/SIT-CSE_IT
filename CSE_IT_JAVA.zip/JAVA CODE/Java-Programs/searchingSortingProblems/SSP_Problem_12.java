package searchingSortingProblems;
public class SSP_Problem_12 {
    public static void main(String[] args) {

    }
}