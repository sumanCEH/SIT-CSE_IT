package basic_idea_of_DS;

import java.util.HashSet;

public class MyHashSet {

	public static void main(String[] args) {
		
		HashSet<String> hs = new HashSet<>();
		
		hs.add("Beta");
		hs.add("Alpha");
		hs.add("Gama");
		hs.add("Eplision");
		hs.add("Omega");
		
		System.out.println(hs);
		
	}

}
