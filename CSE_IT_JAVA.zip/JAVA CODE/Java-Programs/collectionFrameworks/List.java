package basic_idea_of_DS;

import java.util.LinkedList;
public class List{
		public static void main(String[] args) {

			LinkedList<String> ll = new LinkedList<>();  
				    
			ll.add("Aman");  
			ll.add("Soni");  
			ll.add(1, "Kumar");  
			System.out.println(ll);  
		} 
}
