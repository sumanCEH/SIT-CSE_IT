package arrays;

/* Problem Title :-> Best Time to buy and sell stocks */
public class Array_Problem_17 {

  public int maxProfit(int[] prices) {
    int maxProfit = 0;
    return maxProfit;
  }
}
