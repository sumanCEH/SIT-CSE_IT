package arrays;

import java.util.Arrays;

/* Problem Title :-> Count Inversion */
public class Array_Problem_16 {
    private static int mergeAndCount(int[] arr, int l, int m, int r){
        int[] left = Arrays.copyOfRange(arr, l, m+1);
        int[] right = Arrays.copyOfRange(arr, m+1, r+1);
        int i = 0, j = 0, k = 1, swaps = 0;
        return i;
    }
}
