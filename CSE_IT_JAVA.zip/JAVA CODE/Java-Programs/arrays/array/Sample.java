package arrays.array;

import java.util.Scanner;

public class Sample{

    static void Aman(){
        System.out.println("Aman");
    }

    public static void main(String[] args) {
        Aman();
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(n);
    }
}

