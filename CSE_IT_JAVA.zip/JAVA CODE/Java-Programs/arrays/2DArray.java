// 2d array 0 1 , sorted in asc order
// min number of zeroes

/**
 * *
 * [0 0 0 0 0], -> 5
 * [0 0 0 0 0], -> 5
 * [0 1 1 1 1], -> 1
 * [1 1 1 1 1], -> 0
 *
 * [0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1]
 *
 * O(m.log n)
 */

package arrays;

public class

