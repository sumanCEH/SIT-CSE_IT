package arrays.aarrays;
//Check whether an arrays.array is a subset of another arrays.array
public class Check_Subsetness {
    public static void main(String[] args) {

    }
}