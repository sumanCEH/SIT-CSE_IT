package matrix;
// Problem Title => Search element in matrix
public class Search_in_matix {
    public static int search(int[][] arr, int e){

        return e;
    }
    public static void main(String[] args) {

    }
}