package linkedList;
public class MainList {

	public static void main(String[] args) {
		
		MyLL myll = new MyLL();
		
		
		myll.add(0);
		myll.add(1);
		myll.add(2);
		myll.add(3);
		myll.add(4);
		
		myll.print();
	}
	
}
