//package stack_and_queue;
//
//import java.util.LinkedList;
//import java.util.Stack;
//import java
//
//public class P22 {
//
//    static boolean checkStackPermutation(int[] ip, int[] op, int n){
//        Queue<Integer> input = new LinkedList<>();
//    }
//    public static void main(String[] args) {
//
//    }
//}