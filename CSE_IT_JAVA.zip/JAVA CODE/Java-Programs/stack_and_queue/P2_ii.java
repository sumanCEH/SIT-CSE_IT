package stack_and_queue;

//Implement Queue from scratch using Linked-linkedList.list
public class P2_ii {

	public static void main(String[] args) {
		

	}

}
