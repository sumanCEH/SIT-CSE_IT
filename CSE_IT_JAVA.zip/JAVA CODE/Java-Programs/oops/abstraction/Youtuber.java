package oops.abstraction;

public abstract interface Youtuber{
    abstract void makeVideo();
}