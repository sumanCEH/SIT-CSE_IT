package oops.abstraction;

public abstract interface Student{
    abstract void study();
}