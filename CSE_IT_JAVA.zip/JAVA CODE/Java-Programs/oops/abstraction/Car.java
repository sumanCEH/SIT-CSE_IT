package oops.abstraction;

public abstract class Car {
	public abstract void accelerate();
	public abstract void apply_break();
}
