package oops.staticKeyword;

public class Person {
    int age;
    String name;
    final static String breed = "HomoSapiens";
}