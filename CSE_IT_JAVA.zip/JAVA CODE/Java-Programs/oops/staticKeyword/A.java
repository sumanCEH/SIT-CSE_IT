package oops.staticKeyword;

public class A {
    class B{
        int age;
    }
    static class C{
        String name;
    }
}