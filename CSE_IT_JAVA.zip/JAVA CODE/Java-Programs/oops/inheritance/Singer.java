package oops.inheritance;

public class Singer extends Person {
    public void sing(){
        System.out.println(name + "is singing");
    }
}