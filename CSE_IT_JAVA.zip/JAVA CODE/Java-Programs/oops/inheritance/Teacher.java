package oops.inheritance;

public class Teacher extends Person {
    public void teach(){
        System.out.println(name + "is teaching");
    }
}